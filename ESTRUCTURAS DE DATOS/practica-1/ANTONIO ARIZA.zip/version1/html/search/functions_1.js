var searchData=
[
  ['beta',['beta',['../classed_1_1Vector3D.html#a18a5bc2930896a63f5b2c3f689c14cd4',1,'ed::Vector3D']]]
];
